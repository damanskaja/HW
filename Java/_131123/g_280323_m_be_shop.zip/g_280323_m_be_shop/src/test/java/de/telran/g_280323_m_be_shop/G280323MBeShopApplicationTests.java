package de.telran.g_280323_m_be_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G280323MBeShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
