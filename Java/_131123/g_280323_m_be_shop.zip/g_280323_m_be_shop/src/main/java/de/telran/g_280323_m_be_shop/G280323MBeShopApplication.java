package de.telran.g_280323_m_be_shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G280323MBeShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(G280323MBeShopApplication.class, args);
	}

}
